#!/usr/bin/env python3
# Copyright 2026 Canonical Ltd.
# See LICENSE file for licensing details.

"""Handler for TLS events."""

import logging
from typing import TYPE_CHECKING

from ops import (
    ActionEvent,
    Object,
    RelationBrokenEvent,
    RelationCreatedEvent,
)

from opensearch_single_kernel.common.constants import (
    OLD_CA_ALIAS,
    OPENSEARCH_USERS,
    TLS_RELATION,
    CertType,
    DeploymentType,
    Scope,
    StoreType,
)
from opensearch_single_kernel.common.exceptions import (
    OpenSearchError,
    OpenSearchFileOperationError,
)
from opensearch_single_kernel.lib.charms.tls_certificates_interface.v3.tls_certificates import (
    CertificateAvailableEvent,
    CertificateExpiringEvent,
    CertificateInvalidatedEvent,
    TLSCertificatesRequiresV3,
)
from opensearch_single_kernel.utils.helpers import generate_password
from opensearch_single_kernel.utils.secrets import password_key

if TYPE_CHECKING:
    from opensearch_single_kernel.charms.base import OpenSearchBaseCharm

logger = logging.getLogger(__name__)


class TLSEventsHandler(Object):
    """Class implementing OpenSearch TLS events handling."""

    def __init__(self, charm: "OpenSearchBaseCharm"):
        super().__init__(charm, key="tls_events")
        self.charm = charm

        # Requirer
        self.certs = TLSCertificatesRequiresV3(charm, TLS_RELATION, expiry_notification_time=23)

        # Events
        self.framework.observe(
            self.charm.on[TLS_RELATION].relation_created, self._on_tls_relation_created
        )
        self.framework.observe(
            self.charm.on[TLS_RELATION].relation_broken, self._on_tls_relation_broken
        )

        self.framework.observe(self.certs.on.certificate_available, self._on_certificate_available)
        self.framework.observe(self.certs.on.certificate_expiring, self._on_certificate_expiring)
        self.framework.observe(
            self.certs.on.certificate_invalidated, self._on_certificate_invalidated
        )

        # Actions
        self.framework.observe(self.charm.on.set_tls_private_key_action, self._on_set_private_key)
        self.framework.observe(self.charm.on.set_password_action, self._on_set_password_action)
        self.framework.observe(self.charm.on.get_password_action, self._on_get_password_action)

    def _on_set_private_key(self, event: ActionEvent) -> None:
        """Set the TLS private key, which will be used for requesting the certificate."""
        if not self.charm.state.application.deployment_desc:
            event.fail("The action can only be run once the deployment is complete.")
            return
        if self.charm.upgrades_manager.in_progress:
            event.fail("Setting private key not supported while upgrade in-progress")
            return

        if not self.charm.state.tls_relation:
            event.fail("TLS relation not available.")
            return

        cert_type = CertType(event.params["category"])  # type
        scope = Scope.APP if cert_type == CertType.APP_ADMIN else Scope.UNIT
        if scope == Scope.APP and not (
            self.charm.unit.is_leader()
            and self.charm.state.application.deployment_desc.typ
            == DeploymentType.MAIN_ORCHESTRATOR
        ):
            event.fail(
                "Only the juju leader unit of the main orchestrator can set private key for the admin certificates."
            )
            return

        try:
            secrets = {
                "key": event.params.get("key", None),
                "key-password": event.params.get("password", None),
            }
            csr = self.charm.tls_manager.create_certificate_signing_request(
                scope, cert_type, secret=secrets
            )
            self.certs.request_certificate_creation(certificate_signing_request=csr)

        except ValueError as e:
            event.fail(str(e))

    def _on_tls_relation_created(self, event: RelationCreatedEvent) -> None:
        """Request certificate when TLS relation created."""
        if not (self.charm.workload.workload_present or self.charm.workload.can_connect):
            logger.warning("Workload not ready for TLS relation created, deferring.")
            event.defer()
            return

        if self.charm.upgrades_manager.in_progress:
            logger.warning(
                "Modifying relations during an upgrade is not supported."
                "The charm may be in a broken, unrecoverable state"
            )
            event.defer()
            return

        if not (deployment_desc := self.charm.state.application.deployment_desc):
            event.defer()
            return

        if self.charm.unit.is_leader() and deployment_desc.typ == DeploymentType.MAIN_ORCHESTRATOR:
            # create passwords for both ca trust_store/admin key_store
            self.charm.tls_manager.create_store_pwd_if_not_exists(
                Scope.APP, CertType.APP_ADMIN, StoreType.TRUSTSTORE
            )
            self.charm.tls_manager.create_store_pwd_if_not_exists(
                Scope.APP, CertType.APP_ADMIN, StoreType.KEYSTORE
            )
            csr = self.charm.tls_manager.create_certificate_signing_request(
                Scope.APP, CertType.APP_ADMIN
            )
            self.certs.request_certificate_creation(certificate_signing_request=csr)
        elif not self.charm.state.application.admin_secrets.get("truststore-password"):
            logger.debug("Truststore-password from main-orchestrator not available yet.")
            event.defer()
            return

        # create passwords for both unit-http/transport key_stores
        self.charm.tls_manager.create_store_pwd_if_not_exists(
            Scope.UNIT, CertType.UNIT_TRANSPORT, StoreType.KEYSTORE
        )
        self.charm.tls_manager.create_store_pwd_if_not_exists(
            Scope.UNIT, CertType.UNIT_HTTP, StoreType.KEYSTORE
        )

        unit_transport_csr = self.charm.tls_manager.create_certificate_signing_request(
            Scope.UNIT, CertType.UNIT_TRANSPORT
        )
        unit_http_csr = self.charm.tls_manager.create_certificate_signing_request(
            Scope.UNIT, CertType.UNIT_HTTP
        )

        self.certs.request_certificate_creation(certificate_signing_request=unit_transport_csr)
        self.certs.request_certificate_creation(certificate_signing_request=unit_http_csr)

    def _on_certificate_available(self, event: CertificateAvailableEvent) -> None:  # noqa: C901
        """Enable TLS when TLS certificate available.

        CertificateAvailableEvents fire whenever a new certificate is created by the TLS charm.
        """
        if not (deployment_desc := self.charm.state.application.deployment_desc):
            logger.debug("Deployment description not yet computed, deferring event.")
            event.defer()
            return

        if not (self.charm.workload.workload_present or self.charm.workload.can_connect):
            logger.warning("Workload not ready for certificate available, deferring.")
            event.defer()
            return

        try:
            scope, cert_type, secrets = self.charm.tls_manager.find_secret(
                event.certificate_signing_request, "csr"
            )
            logger.debug("%s.%s TLS certificate available.", scope.val, cert_type.val)
        except TypeError:
            logger.debug("Unknown certificate available.")
            return
        # variables for better readability
        deployment_desc = self.charm.state.application.deployment_desc
        is_main_orchestrator = deployment_desc.typ == DeploymentType.MAIN_ORCHESTRATOR

        logger.debug("Received certificate for scope: %s, cert_type: %s", scope.val, cert_type.val)

        if not self.charm.unit.is_leader() and scope == Scope.APP:
            return

        old_cert = secrets.get("cert", None)
        ca_chain = "\n".join(event.chain[::-1])

        self.charm.tls_manager.update_certificate_secret_if_needed(
            scope=scope,
            cert_type=cert_type,
            ca_chain=ca_chain,
            certificate=event.certificate,
            ca=event.ca,
        )

        try:
            current_stored_ca = self.charm.tls_manager.read_stored_ca()

        except OpenSearchFileOperationError as e:
            logger.error("Error while reading stored CA certificate: %s", e)
            event.defer()
            return
        logger.debug("Current stored CA: %s, New CA: %s", current_stored_ca, event.ca)
        if current_stored_ca != event.ca:
            if not self.charm.tls_manager.store_new_ca(
                cert_type,
                create_store_pwd=self.charm.unit.is_leader() and is_main_orchestrator,
            ):
                logger.debug("Could not store new CA certificate.")
                event.defer()
                return

            # replacing the current CA initiates a rolling restart and certificate renewal
            # the workflow is the following:
            # get new CA -> set tls_ca_renewing -> restart -> post_start_init -> set tls_ca_renewed
            # -> request new certs -> get new certs -> on_tls_conf_set
            # -> delete both tls_ca_renewing and tls_ca_renewed
            if current_stored_ca:
                self.charm.state.server.tls_ca_renewing = True
                peer_clusters_servers = self.charm.state.all_peer_clusters_servers(remote=False)
                for peer_cluster_server in peer_clusters_servers:
                    peer_cluster_server.tls_ca_renewing = True
                logger.debug("Restarting opensearch due to CA rotation")
                self.charm.restart_opensearch_event.emit()
                event.defer()
                return

        # store the certificates and keys in a key store
        if not self.charm.tls_manager.store_new_tls_resources(
            cert_type, self.charm.tls_manager.get_secrets_for_cert_type(cert_type)
        ):
            event.defer()
            return

        # apply the chain.pem file for API requests, only if the CA cert has not been updated
        admin_secrets = self.charm.state.application.admin_secrets
        try:
            old_ca_present = self.charm.tls_manager.read_stored_ca(alias=OLD_CA_ALIAS)
        except OpenSearchFileOperationError as e:
            logger.error("Error while reading stored CA certificate: %s", e)
            event.defer()
            return

        if admin_secrets.get("chain") and not old_ca_present:
            if not self.charm.tls_manager.update_request_ca_bundle():
                event.defer()
                return

        # store the admin certificates in non-leader units
        # if admin cert not available we need to defer, otherwise it will never be stored
        if not self.charm.unit.is_leader():
            if admin_secrets.get("cert"):
                if not self.charm.tls_manager.store_new_tls_resources(
                    CertType.APP_ADMIN, admin_secrets
                ):
                    event.defer()
                    return
            else:
                logger.info("Admin certificate not available yet. Waiting for next events.")
                event.defer()
                return

        for external_client in self.charm.state.external_clients:
            try:
                external_client.tls_ca = self.charm.state.secrets.get_object(
                    Scope.APP, CertType.APP_ADMIN.val
                )["chain"]
            except KeyError as e:
                # As we are setting the ca_chain, it should not be likely to happen a KeyError at
                # update_certs. This logic is left for a very corner case.
                logger.error("Failed to update relation TLS info: missing key %s", str(e))
                event.defer()
                return

        # broadcast secret updates for certs and CA to related sub-clusters
        if self.charm.unit.is_leader() and self.charm.state.is_peer_cluster_provider(typ="main"):
            self.charm.peer_cluster_orchestrator_manager.refresh_relation_data()

        renewal = old_ca_present is not None or (
            old_cert is not None and old_cert != event.certificate
        )

        try:
            self.on_tls_conf_set(event, scope, cert_type, renewal)
        except (OpenSearchError, OpenSearchFileOperationError) as e:
            logger.exception(e)
            event.defer()

    def _on_certificate_expiring(
        self, event: CertificateExpiringEvent | CertificateInvalidatedEvent
    ) -> None:
        """Request the new certificate when old certificate is expiring."""
        del self.charm.state.server.tls_configured

        peer_clusters_servers = self.charm.state.all_peer_clusters_servers(remote=False)
        for peer_cluster_server in peer_clusters_servers:
            del peer_cluster_server.tls_configured
        try:
            scope, cert_type, secrets = self.charm.tls_manager.find_secret(
                event.certificate, "cert"
            )
            logger.debug("%s.%s TLS certificate expiring.", scope.val, cert_type.val)
        except TypeError:
            logger.debug("Unknown certificate expiring.")
            return

        old_csr = secrets["csr"].encode("utf-8")

        new_csr = self.charm.tls_manager.create_certificate_signing_request(
            scope=scope, cert_type=cert_type, secret=secrets, tls_file=False
        )
        self.certs.request_certificate_renewal(
            old_certificate_signing_request=old_csr,
            new_certificate_signing_request=new_csr,
        )

    def _on_certificate_invalidated(self, event: CertificateInvalidatedEvent) -> None:
        """Handle a cert that was revoked or has expired"""
        logger.debug("Received certificate invalidation. Reason: %s", event.reason)
        self._on_certificate_expiring(event)

    def _on_tls_relation_broken(self, event: RelationBrokenEvent) -> None:
        """Notify the charm that the relation is broken."""
        if self.charm.upgrades_manager.in_progress:
            logger.warning(
                "Modifying relations during an upgrade is not supported."
                "The charm may be in a broken, unrecoverable state"
            )

    def on_tls_conf_set(
        self,
        event: CertificateAvailableEvent,
        scope: Scope,
        cert_type: CertType,
        renewal: bool,
    ) -> None:
        """Called after certificate ready and stored on the corresponding scope databag.

        - Store the cert on the file system, on all nodes for APP certificates
        - Update the corresponding yaml conf files
        - Run the security admin script

        Raises:
            OpenSearchFileOperationError: If there is an error while operating with certificate
              files.
        """
        if scope == Scope.UNIT:
            admin_secrets = self.charm.state.application.admin_secrets
            if not admin_secrets.get("truststore-password"):
                event.defer()
                return

            self.charm.config_manager.update_opensearch_config()
            # write the admin cert conf on all units, in case there is a leader loss + cert renewal
            if not admin_secrets.get("subject"):
                return

        if not self.charm.tls_manager.store_admin_tls_secrets_if_applies():
            event.defer()
            return

        # In case of renewal of the unit transport layer cert - restart opensearch
        if not renewal or not self.charm.state.application.is_admin_user_initialized:
            return

        if not self.charm.tls_manager.is_fully_configured():
            logger.debug("TLS not fully configured yet, deferring event.")
            event.defer()
            return

        if self.charm.state.server.started:
            if not self.charm.tls_manager.reload_tls_certificates():
                self.charm.restart_opensearch_event.emit()
                return

        self.charm.state.reset_ca_rotation_state()
        # if all certs are stored and CA rotation is complete in the cluster
        # we delete the old ca and update the chain to only include the new one
        if (
            self.charm.tls_manager.read_stored_ca(OLD_CA_ALIAS)
            and self.charm.state.ca_and_certs_rotation_complete_in_cluster
        ):
            logger.info("on_tls_conf_set: Detected CA rotation complete in cluster")
            self.charm.tls_manager.finalize_ca_certs_rotation()

    def _on_set_password_action(self, event: ActionEvent) -> None:
        """Set new admin password from user input or generate if not passed."""
        if not self.charm.state.application.deployment_desc:
            event.fail("The action can only be run once the deployment is complete.")
            return
        if self.charm.state.application.deployment_desc.typ != DeploymentType.MAIN_ORCHESTRATOR:
            event.fail("The action can only be run on the main orchestrator cluster.")
            return
        if not self.charm.unit.is_leader():
            event.fail("The action can only be run on leader unit.")
            return
        if self.charm.upgrades_manager.in_progress:
            event.fail("Setting password not supported while upgrade in-progress")
            return

        user_name = event.params.get("username")
        if user_name not in OPENSEARCH_USERS:
            event.fail(f"Only the {OPENSEARCH_USERS} usernames are allowed for this action.")
            return

        password = event.params.get("password") or generate_password()
        try:
            self.charm.internal_users_manager.put_or_update_internal_user_leader(
                user_name, password
            )
            label = password_key(user_name)
            event.set_results({label: password})
            # We know we are already running for MAIN_ORCH. and its leader unit
            self.charm.peer_cluster_orchestrator_manager.refresh_relation_data()
        except OpenSearchError as e:
            event.fail(f"Failed changing the password: {e}")
        except RuntimeError as e:
            # From:
            # https://github.com/canonical/operator/blob/ \
            #     eb52cef1fba4df2f999f88902fb39555fb6de52f/ops/charm.py
            # if str(e) == "cannot defer action events":
            #    event.fail("Cluster is not ready to update this password. Try again later.")
            # else:
            event.fail(f"Failed with unknown error: {e}")

    def _on_get_password_action(self, event: ActionEvent) -> None:
        """Return the password and cert chain for the admin user of the cluster."""
        if not self.charm.state.application.deployment_desc:
            event.fail("The action can only be run once the deployment is complete.")
            return

        user_name = event.params.get("username")
        if user_name not in OPENSEARCH_USERS:
            event.fail(f"Only the {OPENSEARCH_USERS} username is allowed for this action.")
            return

        if not self.charm.state.application.is_admin_user_initialized:
            event.fail(f"{user_name} user not configured yet.")
            return

        if not self.charm.tls_manager.is_fully_configured():
            event.fail("TLS certificates not configured yet.")
            return

        password = self.charm.state.application.get_user_password(user_name)

        event.set_results(
            {
                "username": user_name,
                "password": password,
                "ca-chain": self.charm.state.application.admin_secrets["chain"],
            }
        )
